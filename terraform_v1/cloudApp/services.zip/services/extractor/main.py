import base64
import json
import os
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer

import requests
from google.cloud import pubsub_v1

# ---- Minimal HTTP server for Cloud Run health / PORT ----
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ("/", "/healthz", "/health"):
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"ok")
        else:
            self.send_response(404)
            self.end_headers()

def run_http_server():
    port = int(os.environ.get("PORT", "8080"))
    server = HTTPServer(("0.0.0.0", port), Handler)
    server.serve_forever()

# Start server in background
threading.Thread(target=run_http_server, daemon=True).start()

# ---- Worker loop ----
PROJECT_ID = os.environ["GCP_PROJECT"]
TOPIC_NAME = os.environ["PUBSUB_TOPIC"]
STREAM_URL = os.environ["STREAM_URL"]
FPS = float(os.environ.get("FPS", "2"))
CAMERA_ID = os.environ.get("CAMERA_ID", "cam1")
JPEG_QUALITY = int(os.environ.get("JPEG_QUALITY", "70"))

publisher = pubsub_v1.PublisherClient()
topic_path = publisher.topic_path(PROJECT_ID, TOPIC_NAME)

seq = 0

def now_iso():
    return datetime.now(timezone.utc).isoformat()

while True:
    t0 = time.time()
    try:
        r = requests.get(STREAM_URL, timeout=5)
        r.raise_for_status()
        img_bytes = r.content

        msg = {
            "ts": now_iso(),
            "camera_id": CAMERA_ID,
            "seq": seq,
            "mime": "image/jpeg",
            "jpeg_q": JPEG_QUALITY,
            "data_b64": base64.b64encode(img_bytes).decode("ascii"),
        }
        seq += 1

        publisher.publish(topic_path, json.dumps(msg).encode("utf-8"))
        print(f"published seq={seq}", flush=True)

    except Exception as e:
        print(f"error: {e}", flush=True)

    dt = time.time() - t0
    time.sleep(max(0.0, (1.0 / FPS) - dt))