import base64
import json
import os
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer

import cv2
import numpy as np
from google.cloud import pubsub_v1

PROJECT_ID = os.environ["GCP_PROJECT"]
DETECTIONS_TOPIC = os.environ["DETECTIONS_TOPIC"]

publisher = pubsub_v1.PublisherClient()
topic_path = publisher.topic_path(PROJECT_ID, DETECTIONS_TOPIC)

def now_iso():
    return datetime.now(timezone.utc).isoformat()

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ("/", "/healthz", "/health"):
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"ok")
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path != "/pubsub":
            self.send_response(404)
            self.end_headers()
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            body = self.rfile.read(length)
            envelope = json.loads(body.decode("utf-8"))

            # Pub/Sub push envelope
            msg = envelope["message"]
            data_raw = base64.b64decode(msg["data"]).decode("utf-8")
            data = json.loads(data_raw)

            # our frame payload
            img_bytes = base64.b64decode(data["data_b64"])
            img_array = np.frombuffer(img_bytes, dtype=np.uint8)
            img = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
            h, w = img.shape[:2]

            box = {
                "label": "test_object",
                "confidence": 0.99,
                "bbox": [int(w*0.25), int(h*0.25), int(w*0.75), int(h*0.75)]
            }

            out = {
                "ts": now_iso(),
                "camera_id": data.get("camera_id", "cam1"),
                "seq": data.get("seq", -1),
                "detections": [box],
            }

            publisher.publish(topic_path, json.dumps(out).encode("utf-8"))
            print(f"processed frame seq={out['seq']}", flush=True)

            # ACK
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")

        except Exception as e:
            print(f"error: {e}", flush=True)
            # NACK by non-2xx so Pub/Sub retries
            self.send_response(500)
            self.end_headers()
            self.wfile.write(b"error")

def main():
    port = int(os.environ.get("PORT", "8080"))
    server = HTTPServer(("0.0.0.0", port), Handler)
    print("Judge HTTP server listening...", flush=True)
    server.serve_forever()

if __name__ == "__main__":
    main()